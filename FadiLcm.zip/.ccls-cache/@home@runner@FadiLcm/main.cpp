#include <iostream>
#include <cmath>
using namespace std;

long mcd(long long int a, long long int b) {
  
  if (b == 0) {
    return a;
    }
    return mcd(b, a % b);
}


int main() {
  long long int x,a,b=0,a1,b1;
  while(cin >> x){
for (int i = 1; i <= sqrt(x); i++) {
  
  if (x % i == 0) {
    a = i;
    b = x / i;
     if (mcd(b, a) == 1) {
      a1 = b;
      b1 = x / b;
      }
    }
  }
}
  cout << b1 << " " << a1 ;
}
