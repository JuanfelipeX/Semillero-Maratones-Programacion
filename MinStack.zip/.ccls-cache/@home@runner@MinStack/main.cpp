#include <stdio.h>
#include <iostream>
#include <stack>
using namespace std;

class MinStack{
    stack<int> s;
    public: int min;
    
    void push(int x){
        if(s.empty()){
            s.push(x);
        }else if(x > min){
            s.push(x);
        }else{
            s.push(2*x - min);
            min = x;
        }
    }
    
    void pop(){
        if(s.empty()){
            printf("Stack underflow");
        }
        
        int top = s.top();
        
        if (top < min){
            min = 2*min - top;
        }
        
        s.pop();
    }
    
    int mini(){
        return min;
    }
};

int main() {
    
    MinStack s = MinStack();
    stack<int> stack;
    int n, m, num;
    
    scanf("%d", &num);

    char str[20];

    for(int i = 0; i < num; i++) {
        scanf("%s",str);
        if(str[1] == 'U') {
            scanf("%d", &m);
            stack.push(m);
            s.push(m);
        
        }
        else if(str[0] == 'M') {
            if(stack.empty())
                printf("EMPTY\n");
            else{
                s.mini();
            }
        }
        else if(str[2] == 'P'){
            if(stack.empty())
                printf("EMPTY\n");
            else {
                int temp = stack.top();
                stack.pop();
                s.pop();
            }
        }
    }
}

