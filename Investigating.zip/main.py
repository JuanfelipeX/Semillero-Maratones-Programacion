t = int(input()) #input de cantidad de iteraciones.

for cant in range(t):

  cadena = input().split(" ") #input de los numeros enteros.

  A = int(cadena[0])
  B = int(cadena[1])
  K = int(cadena[2])

  if (K >= 100 ):
    print(0)
  
  else:
    count = 0
      
    for i in range(A,B+1):
      total = 0
      x = [int(a) for a in str(i)] #para transformar los digitos de los numeros en una lista.

      for j in range(0, len(x)): #para sumar los numeros de una lista.
    
        total = total + x[j]
  
      if(i % K == 0 and total % K == 0): 
        count += 1
  print(count)