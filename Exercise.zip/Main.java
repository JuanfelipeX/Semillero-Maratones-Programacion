import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.*;

class Main {

  public static Scanner sc = new Scanner(System.in);
  
  public static void main(String[] args) {
   
   char cards [][] = new char[52][32];
     
    int T = sc.nextInt();
    
    for (int t = 1; t <= T; ++t){
       for (int x=0; x < cards.length; x++) {
        for (int y=0; y < cards[x].length; y++) {
        cards[x][y] = sc.next().charAt(0);
      }
     }
for (int x=0; x < cards.length; x++) {
  for (int y=0; y < cards[x].length; y++) {
    System.out.println ("[" + x + "," + y + "] = " + cards[x][y]);
  }
}
    }
  }
}