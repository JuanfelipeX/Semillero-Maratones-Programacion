#include <iostream>
#include <cmath>
using namespace std;

int main() {
  int t, n=0, a, r, k=0, j=0;
  cin >> t;
  while(t--){
    cin >> n;
    a =n;

    while(a!=0){
      a/=10;
    }

    for (a=n; a!=0; a/=10) {
      r = a%10;
      k+=pow(r, j);
    }
    if(k==a){
      cout << "Arstromg";
    } else{
      cout << "not Arstromg";
    }
  }
}